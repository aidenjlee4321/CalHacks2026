'use client';

import { useMemo } from 'react';
import { useTable, useReducer, useSpacetimeDB } from 'spacetimedb/react';
import { tables, reducers } from '../lib/module_bindings';

export interface OrgNode {
  id: string;
  name: string;
  type: string;
  status?: string;
  superior?: string;
  reportsToJson?: string;
  subordinatesJson?: string;
}

export interface TaskItem {
  id: string;
  assignedNodeId: string;
  title: string;
  completed: boolean;
}

function firstParent(reportsToJson?: string): string | undefined {
  if (!reportsToJson) return undefined;
  try {
    const parsed = JSON.parse(reportsToJson);
    if (Array.isArray(parsed)) return parsed[0] ? String(parsed[0]) : undefined;
    if (typeof parsed === 'string' && parsed) return parsed;
  } catch {
    if (reportsToJson && reportsToJson !== '[]') return reportsToJson;
  }
  return undefined;
}

export function useOrgData() {
  const { isActive: isConnected, identity: rawIdentity } = useSpacetimeDB();
  const identity = rawIdentity
    ? typeof (rawIdentity as { toHexString?: () => string }).toHexString === 'function'
      ? (rawIdentity as { toHexString: () => string }).toHexString()
      : String(rawIdentity)
    : null;

  const [nodeRows] = useTable(tables.orgNode);
  const [taskRows] = useTable(tables.task);

  const addNodeReducer = useReducer(reducers.addNode);
  const updateStatusReducer = useReducer(reducers.updateStatus);
  const assignTaskReducer = useReducer(reducers.assignTask);
  const completeTaskReducer = useReducer(reducers.completeTask);

  const nodes: OrgNode[] = useMemo(
    () =>
      nodeRows.map((r) => ({
        id: r.id,
        name: r.name,
        type: r.type,
        status: r.status,
        reportsToJson: r.reportsToJson,
        subordinatesJson: r.subordinatesJson,
        superior: firstParent(r.reportsToJson),
      })),
    [nodeRows]
  );

  const tasks: TaskItem[] = useMemo(
    () =>
      taskRows.map((r) => ({
        id: r.id,
        assignedNodeId: r.nodeId,
        title: r.description,
        completed: r.status === 'COMPLETED',
      })),
    [taskRows]
  );

  const addNode = (name: string, type: string, _superiorId: string) => {
    const id = crypto.randomUUID();
    addNodeReducer({ id, name: name.trim() || 'New Member', type });
    return id;
  };

  const updateNode = (_id: string, _name: string, _type: string, _superiorId: string) => {
    // Live schema has no update_node reducer yet — status updates go through updateNodeStatus.
  };

  const updateNodeStatus = (id: string, status: string) => {
    updateStatusReducer({ id, status });
  };

  const deleteNode = (_id: string) => {
    // Live schema has no delete_node reducer yet.
  };

  const addTask = (nodeId: string, title: string) => {
    assignTaskReducer({ nodeId, description: title });
  };

  const deleteTask = (_taskId: string) => {
    // Live schema has no delete_task reducer yet.
  };

  const toggleTask = (taskId: string) => {
    const row = taskRows.find((t) => t.id === taskId);
    if (!row || row.status === 'COMPLETED') return;
    completeTaskReducer({ taskId });
  };

  return {
    nodes,
    tasks,
    setNodes: (_: OrgNode[]) => {},
    setTasks: (_: TaskItem[]) => {},
    isConnected: Boolean(isConnected),
    identity,
    addNode,
    updateNode,
    updateNodeStatus,
    deleteNode,
    addTask,
    deleteTask,
    toggleTask,
  };
}
